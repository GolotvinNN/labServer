﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EagerInitialization
{

    public sealed class Servers
    {
        private static readonly Servers _instance = new Servers();
        private readonly List<string> _servers = new List<string>();
        private readonly object _lock = new object();

        static Servers() { }

        private Servers() { }

        public static Servers Instance => _instance;

        public bool AddServer(string address)
        {
            if (!address.StartsWith("http://") && !address.StartsWith("https://"))
                return false;

            lock (_lock)
            {
                if (_servers.Contains(address))
                    return false;

                _servers.Add(address);
                return true;
            }
        }

        public List<string> GetHttpServers()
        {
            lock (_lock)
            {
                return _servers.Where(server => server.StartsWith("http://")).ToList();
            }
        }

        public List<string> GetHttpsServers()
        {
            lock (_lock)
            {
                return _servers.Where(server => server.StartsWith("https://")).ToList();
            }
        }
    }
}
