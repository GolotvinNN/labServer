﻿using ConsoleApp1;

public class Program
{
    public static void Main()
    {
        Servers servers = Servers.Instance;

        Console.WriteLine(servers.AddServer("http://test.com"));  // True
        Console.WriteLine(servers.AddServer("https://test.com")); // True
        Console.WriteLine(servers.AddServer("ftp://test.com"));   // False
        Console.WriteLine(servers.AddServer("http://test.com"));  // False

        var httpServers = servers.GetHttpServers();
        var httpsServers = servers.GetHttpsServers();

        Console.WriteLine(string.Join(", ", httpServers));
        Console.WriteLine(string.Join(", ", httpsServers));
    }
}
